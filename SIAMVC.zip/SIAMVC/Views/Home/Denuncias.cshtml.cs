using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SIAMVC.Views.Home
{
    public class DenunciasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
